import 'package:flutter/animation.dart';
import 'package:flutter/material.dart';

class AppColors {
  static const Color main = Color(0xFF67C4A7);
  static const Color secondary = Color(0xFF939393);
  static const Color text1Color = Color(0xFF393F42);
  static const Color text2Color = Color(0xFFC8C8CB);
}
