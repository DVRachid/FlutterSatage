import 'dart:math';
import 'package:agent/Store/components/product_card.dart';
import 'package:agent/Store/constants/dimesions.dart';
import 'package:agent/Store/components/cart_item.dart';
import 'package:agent/Store/components/my_text.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';

class Products extends StatelessWidget {
  const Products({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            MyText(
              text: 'Products',
              size: Dimensions.font16,
              weight: FontWeight.w500,
            ),
            IconButton(
              onPressed: () {},
              icon: const Icon(Icons.add),
            )
          ],
        ),
        SizedBox(
          height: Dimensions.height10,
        ),
        StreamBuilder(
          stream: FirebaseDatabase.instance.ref().child('users').onValue,
          builder: (BuildContext context, AsyncSnapshot snapshot) {
            List<Widget> productsInDb = [];
            if (snapshot.hasData &&
                !snapshot.hasError &&
                snapshot.data.snapshot.value != null) {
              final mapOfResult = Map<String, dynamic>.from(
                  (snapshot.data! as DatabaseEvent).snapshot.value as Map);
              mapOfResult.forEach(
                (key, value) {
                  Map CategoryInDb = value['category'];
                  CategoryInDb.forEach(
                    (key, value) {
                      (value['Products'] as Map).forEach((key, value) {
                        productsInDb.add(
                        ProductCard(product: Product(
                          colors: randomColors(),
                          cover: value['ProImageUrl'],
                          desc: value['Description'],
                          name: value['NameProduit'],
                          price: value['Price'],
                        ))
                      );
                    });
                      
                    },
                  );
                },
              );
            }
            return GridView(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisExtent: Dimensions.cardHeight,
              ),
              children: productsInDb,
            );
          },
        ),


      ],
    );
  }
}

Random random = Random();
List<Color> randomColors() {
  List<Color> colors = [];
  for (var i = 0; i < 5; i++) {
    colors
        .add(Color((random.nextDouble() * 0xFFFFFF).toInt()).withOpacity(1.0));
  }
  return colors;
}
